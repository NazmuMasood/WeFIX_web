<?php $__env->startSection('title', 'WeFIX Reports'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Reports</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header" style="background-color:mistyrose;">
	  <h3 class="card-title">
			<i>
				<a id="target">Total Reports</a>
				
				<?php if(session()->has('reportsCount')): ?>
						(<?php echo e(session()->get('reportsCount')); ?>)
				<?php endif; ?>
			</i>
		</h3>
	  <div style="float:right">
			<a href="<?php echo e(action('FirebaseController@static_array_to_csv')); ?>" target="_blank">
				<u>Download as CSV</u>
			</a>
	  </div>
    </div>
    <!-- /.box-header -->
    <div class="card-body">
      <table id="example1" class="table table-bordered table-striped">
        <thead>
        <tr>
            <th style="width:11.5%">Pollution type</th>
			<th>Address</th>
			<th style="width:11.5%">Latitude-Longitude</th>
			<th style="width:11.5%">Extent</th>
			<th style="width:11.5%">Source</th>
			<th style="width:11.5%">Posted At</th>
			<th style="width:11.5%">Audio</th>
			<th style="width:11.5%">Images</th>
        </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $all_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($report['category']); ?></td>
			<td><?php echo e($report['address']); ?></td>

			<td>
				<?php echo e($report['location']['latitude']); ?>, <?php echo e($report['location']['longitude']); ?>

			</td>

			<td><?php echo e($report['extent']); ?></td>
			<td><?php echo e($report['source']); ?></td>
			<td><?php echo e($report['postedAt']); ?></td>
			
			<?php if(array_key_exists('audiosUrl',$report)): ?>
				<td>
					<a href=<?php echo e($report['audiosUrl']); ?> target="_blank">Play audio</a>
				</td>
			<?php else: ?>
				<td> - </td>
			<?php endif; ?>

			<?php if(array_key_exists('imagesUrl',$report)): ?>
				<td>
					<?php $__currentLoopData = $report['imagesUrl']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexKey=>$imageUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a href=<?php echo e($imageUrl); ?> target="_blank">Image-<?php echo e($indexKey+1); ?><br></a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</td>
			<?php else: ?>
				<td> - </td>
			<?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
		
		<tfoot>
			<tr>
				<th>Pollution type</th>
				<th>Address</th>
				<th>Latitude-Longitude</th>
				<th>Extent</th>
				<th>Source</th>
				<th>Posted At</th>
				<th>Audio</th>
				<th>Images</th>
			</tr>
		</tfoot>
      </table>
    </div>
    <!-- /.box-body -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<!-- FOOTER -->
	<footer class="container">
		<p class="float-right"><a href="#">Back to top</a></p>
		<p>&copy; 2020 WeFIX &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
	</footer>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<!-- page script -->
	<script>
		$(function () {
			//if ( $( "[name='anchor']" ).length ) {
				// window.location = '#' + $( "[name='anchor']" ).val();
			//}
			//window.location = '#' + "target";
		});
	</script>
	
	<?php echo $__env->yieldPushContent('js'); ?>
	<?php echo $__env->yieldContent('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wefix\resources\views/pages/reports.blade.php ENDPATH**/ ?>
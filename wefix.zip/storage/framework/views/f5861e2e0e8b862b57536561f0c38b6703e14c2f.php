<?php $__env->startSection('title', 'WeFIX Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(session()->has('flash_notification.success')): ?> 
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <p class="mb-0"><?php echo session('flash_notification.success'); ?></p>
                </div>
            </div>
        </div>
	</div>
	<?php endif; ?>

	<div class="card" style="width: 14rem;">
		<a href="/reports">
			<img class="card-img-top" src="vendor/adminlte/dist/img/web_hi_res_512.png" alt="Card image cap">
			<div class="card-body">
			<h4>
				See Reports
				<?php if(session()->has('reportsCount')): ?>
					(<?php echo e(session()->get('reportsCount')); ?>)
				<?php endif; ?>
			</h4>
			</div>
		</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<!-- FOOTER -->
	<footer class="container">
		<p>&copy; 2020 WeFIX &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
	</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wefix\resources\views/home.blade.php ENDPATH**/ ?>